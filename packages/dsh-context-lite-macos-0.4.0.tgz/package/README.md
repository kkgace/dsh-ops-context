# dsh-context-lite-macos

面向 DSH macOS 用户的工作区上下文精简插件，同一份 Host 插件包可安装到 **DSH 桌面版和网页版**。插件操作 DSH 会话当前授权的 workspace，不尝试越过 DSH 权限直接访问浏览器或宿主文件系统。

## 当前能力

- `context_search`：对当前 workspace 做有界、大小写不敏感的字面搜索，默认跳过隐藏路径、依赖/构建产物/VCS 元数据和明显密钥或凭据文件；只返回相对路径、1-based 行号和短片段。
- `context_read`：按 1-based 行范围读取 workspace 文件；默认最多 120 行、最多 12,000 字符。所有隐藏路径（例如 `.ssh`、`.npmrc`、`.docker`）以及敏感配置/密钥文件默认拒绝读取；需要查看这些文件时使用 DSH 原生只读工具。
- 会话内去重：同一 Agent 会话、本轮、同版本、同范围再次读取时，仅在 Projection 状态未观察到压缩事件时返回“复用前次结果”提示。状态由 DSH `sessionProjections` 依据已提交事件驱动；被字符预算截断的内容不会缓存为完整上下文。上下文压缩后自动重新读取；也可用 `force: true` 显式重读。
- 搜索/读取路径只接受 workspace 相对路径，拒绝 `..` 越界和绝对路径。每次读取都用 DSH `fs.resolve/contains` 验证规范目标在 workspace 内；Host `workspaceFiles` 负责目录 containment、常规文件类型与 symlink 防护。遍历受文件、目录、深度、行数和结果字符预算约束。

## 桌面/Web 兼容方式

插件是 DSH Host 插件，没有 macOS 专属原生载荷，也没有浏览器 UI。它通过 DSH 的 `workspaceFiles` 服务访问当前会话工作区，并从 Agent 会话头读取 workspace 根目录。桌面版和网页版使用各自的 DSH Host/profile，但调用相同插件逻辑；需在两个 profile 分别安装。网页版可处理 DSH 当前挂载到 workspace 的 Mac 项目目录。

**边界：**若 Web profile 的 workspace 未挂载预期目录，插件只会看到该会话实际绑定的工作区，不会扫描 Mac 的其他目录。首版不运行 shell/测试命令，避免误把服务器进程执行当成 Mac 本机执行。

## 安装

从项目目录安装到当前 DSH profile：

```sh
dsh plugin --profile <profile> add /absolute/path/to/dsh-context-lite-macos
```

针对桌面版和 Web 版，应使用各自对应的 profile 分别安装和启用此 bundle。若安装 `desktop` profile，先完全退出 DSH 桌面应用，再运行命令；确认目标 DSH 版本处于 `>=0.2.0-rc.2 <0.3.0`；本版本在 DSH `0.2.0-rc.2` 服务契约上开发。若使用更高/不同版本，先做插件兼容检查，不要通过版本豁免强行启用。

安装后新建或继续一个带 workspace 的 Agent 会话。可让 Agent “在工作区用 context_search 查找……，然后用 context_read 只读相关行”。同一轮重复读取时，压缩历史若已丢失前次内容，工具会重新提供内容而不是要求模型引用不可见信息。

## 配置

所有参数有默认值；可在 profile 插件配置中调节：

| 配置项 | 默认值 | 说明 |
|---|---:|---|
| `maxReadLines` | 120 | 单次读取最大行数，可在 1–500 范围配置 |
| `maxReadChars` | 12,000 | 单次读取最大字符数 |
| `maxSearchFiles` | 400 | 搜索最多扫描文件数 |
| `maxSearchDirs` | 400 | 搜索最多遍历目录数 |
| `maxSearchLinesPerFile` | 400 | 每文件最多检查行数 |
| `maxSearchMatches` | 60 | 搜索最多返回匹配行数 |
| `maxLineChars` | 240 | 单行匹配预览上限 |
| `maxSearchChars` | 16,000 | 搜索输出总字符上限 |

超限时结果带截断说明；可缩窄目录或查询，不会静默声称搜索完整。

## 0.2.0 一次调用自证完整（针对多步补偿成本的实测改进）

基准 v3 实测发现：过小的搜索预算迫使模型用多次补偿调用核验完整性与计数，轮次开销吞掉单次交付节省。0.2.0 据此调整：

- **同行多次命中合并**为一条并标注 `×次数`（如 `bundle.js:1(×3): ...`），无需逐字读取回验；
- **全量扫描自证标记**：无截断时返回 `[全量扫描：N 个文件、M 个目录，共 K 处命中，无遗漏]`，模型无需追加核验；
- **隐藏/凭据文件名可见、内容必拦截**：搜索结果列出 `[隐藏/凭据文件（仅列出文件名，内容一律不读取）：...]`——0 内容泄露不变，但消除"文件名不可枚举"导致的盲目探测；
- 预算放宽（文件 400 / 每文件行数 400 / 匹配 60 / 输出 16,000 字符），多数工作区一次搜索即全覆盖。

## 测试与验证

```sh
npm test
npm run check
npm pack --dry-run
```

测试覆盖 workspace 路径边界、敏感文件过滤、Unicode 输出上限、搜索文件/目录预算、1-based 行偏移、读取去重与 Projection 压缩失效、截断输出不缓存、取消传播、Host 工具注册/卸载。运行时桌面与 Web 的真实挂载目录还需要分别做安装后验收。

## 设计边界

此插件不试图替代 `dsh-context-lens` 的 AST 代码骨架或日志压缩，也不替代 DSH 自带的 `glob`/`grep`/`read`。它聚焦于 workspace-scoped 有界查找、部分读取和同轮重复读取识别。若任务需要更宽泛的检索，继续使用 DSH 原生搜索工具；若希望查看压缩后的代码骨架，可评估既有插件。

MIT License。
